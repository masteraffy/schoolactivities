
package activities;

import java.util.Scanner;
public class Galendez {
    public static void main(String[] args) {
       Scanner s = new Scanner(System.in);
       int choice;
       
       System.out.print("Select the Operation you want: \n"
               + "1: Get Age Only \n"
               + "2: Get Age and Zodiac Sign \n"
               + "3: Get Age and Life Stage\n"
               + "Enter Choice Here: ");
       choice = s.nextInt();
       
        if(choice == 1){
            //object
            Person p = new Person();
            //setters
            System.out.print("Please Enter your Birth Year: ");
            p.setBirth_Year(s.nextInt());
            System.out.print("Please Enter the Current Year: ");
            p.setYear_Today(s.nextInt());
            //compute
            p.computeAge();
            //getter
            System.out.println("Your age is: "+p.getAge());
        }
        
        else if(choice == 2){
            //object
            Zodiac z = new Zodiac();
            //setter
            System.out.print("Please Enter your Birth Year: ");
            z.setBirth_Year(s.nextInt());
            System.out.print("Please Enter the Current Year: ");
            z.setYear_Today(s.nextInt());
            //compute
            z.computeAge();
            //getter
            System.out.print("Your age is: "+z.getAge() + "\nYour Zodiac Sign"
                    + " is: "+z.getZodiac());
        }
        
        else if(choice == 3){
            //object
            LifeCycle lc = new LifeCycle();
            //setters
            System.out.print("Please Enter your Birth Year: ");
            lc.setBirth_Year(s.nextInt());
            System.out.print("Please Enter the Current Year: ");
            lc.setYear_Today(s.nextInt());
            //compute
            lc.computeAge();
            //getter
            System.out.print("Your age is: "+lc.getAge() + "\nYour Life Stage"
                    + " is: "+lc.getLifeStage());
        }
        
        else{
            System.out.print("Invalid Option!");
        }
    
    }
    
}
