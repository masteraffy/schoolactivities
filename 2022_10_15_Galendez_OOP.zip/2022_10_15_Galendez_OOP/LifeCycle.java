
package activities;


public class LifeCycle extends Person {
    public String getLifeStage(){
        int age = super.getAge();
        String lifeStage = null;
        
        if(age == 0 && age <=2 )
            lifeStage = "Baby";
        
        else if(age >=3 && age <=9)
            lifeStage = "Child";
        
        else if(age >=10 && age <=19)
            lifeStage = "Adolescent";
        
        else if(age >=20 && age <=59)
            lifeStage = "Adult";
        
        else if(age >= 60)
            lifeStage = "Senior";
        
        else
            lifeStage = "Invalid";
        
        return lifeStage;
    }
}
