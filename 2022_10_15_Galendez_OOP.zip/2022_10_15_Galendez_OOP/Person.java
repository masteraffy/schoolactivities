
package activities;


public class Person {
    private String name;
    private int birth_year, year_today, age;
    
//    public Person(String name){
//        this.name = name;
//    }
    //setters
    public void setBirth_Year(int value){
        birth_year = value;
    }
    public void setYear_Today(int value){
        year_today = value;
    }
    //computation method
    public void computeAge(){
       age = year_today - birth_year;
    }
    
    public String getName(){
        return name;
    }
    public int getBirth_Year(){
        return birth_year;
    }
    public int getYear_Today(){
        return year_today;
    }
    public int getAge(){
        return age;
    }
}
